Config = {}

Config.Stages = 3
Config.TestMod = false
Config.level = 3